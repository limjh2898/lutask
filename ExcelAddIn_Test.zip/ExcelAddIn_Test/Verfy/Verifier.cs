﻿using ExcelAddIn_Test.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelAddIn_Test.Verfy
{
    public class Verifier
    {
        //public bool Verify(Dictionary<string, string> datas, TableModel model)
        //{

        //}
    }
}
