﻿using Microsoft.Office.Tools.Ribbon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExcelAddIn_Test
{
    public partial class Tool
    {
        private void Ribbon1_Load(object sender, RibbonUIEventArgs e)
        {

        }
    }
}
