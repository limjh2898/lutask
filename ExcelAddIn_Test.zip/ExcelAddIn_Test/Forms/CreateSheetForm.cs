﻿using System;
using System.Windows.Forms;

namespace ExcelAddIn_Test.Forms
{
    public partial class CreateSheetForm : Form
    {
        public CreateSheetForm()
        {
            InitializeComponent();

            var items = new ListViewItem[]
            {
                new ListViewItem("Amy Alberts", "asdasd"),
                new ListViewItem("Amy Recker"),
                new ListViewItem("Erin Hagens"),
                new ListViewItem("Barry Johnson"),
                new ListViewItem("Jay Hamlin"),
                new ListViewItem("Brian Valentine"),
                new ListViewItem("Brian Welker"),
                new ListViewItem("Daniel Weisman") 
            };

            foreach(ListViewItem item in items)
            {
                item.SubItems.Add("The following code example creates");
            }

            tableListView.Items.AddRange(items);
            tableListView.AutoResizeColumn(1, ColumnHeaderAutoResizeStyle.ColumnContent);
        }

        private void searchBox_TextChanged(object sender, EventArgs e)
        { 
            // Call FindItemWithText with the contents of the textbox.
            ListViewItem foundItem = tableListView.FindItemWithText(searchBox.Text, false, 0, true);
            if (foundItem != null)
            {
                tableListView.TopItem = foundItem;
                foundItem.Selected = true;
            }
        }

        private void CreateBtn_Click(object sender, EventArgs e)
        {

        }
        private void CancleBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SheetNameTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
