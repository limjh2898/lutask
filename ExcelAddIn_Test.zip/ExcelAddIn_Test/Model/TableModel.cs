﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace ExcelAddIn_Test.Model
{
    [XmlRoot("table")]
    public class TableModel
    {
        [XmlAttribute("name")]
        public string Name { get; set; } = string.Empty;

        [XmlElement("variable")]
        public List<VariableModel> Variables { get; set; } = new List<VariableModel>();
    }
}
