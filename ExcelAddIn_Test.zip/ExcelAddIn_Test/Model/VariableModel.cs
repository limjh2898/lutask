﻿using System.Xml.Serialization;

namespace ExcelAddIn_Test.Model
{
    public class VariableModel
    {
        [XmlAttribute("name")]
        public string Name { get; set; } = string.Empty;

        [XmlAttribute("type")]
        public string Type { get; set; } = string.Empty;

        [XmlAttribute("meta")]
        public string Meta { get; set; } = string.Empty;
    }
}
