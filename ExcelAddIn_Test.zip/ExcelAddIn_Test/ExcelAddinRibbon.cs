﻿using ExcelAddIn_Test.Forms;
using Microsoft.Office.Core;
using Microsoft.Office.Tools.Ribbon;

namespace ExcelAddIn_Test
{
    public partial class ExcelAddinRibbon
    {
        private void ExcelAddinRibbon_Load(object sender, RibbonUIEventArgs e)
        {

        }

        private void CreateSheetBtn_Click(object sender, RibbonControlEventArgs e)
        {
            CreateSheetForm form = new CreateSheetForm();
            form.Show();
        }
    }
}
